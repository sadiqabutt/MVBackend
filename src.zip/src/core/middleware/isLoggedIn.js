// src/core/middleware/isLoggedIn.js
import { ApiError } from "../utils/api-error.js";
import { asyncHandler } from "../utils/async-handler.js";
import jwt from "jsonwebtoken";
import User from "../../models/User.model.js";
import Admin from "../../models/admin.models.js";

const isLoggedIn = asyncHandler(async (req, res, next) => {
  // First try cookie access token
  const tokenFromCookie = req.cookies?.accessToken;
  // Also allow Authorization header
  const headerToken = req.headers.authorization?.split(" ")[1];

  const token = tokenFromCookie || headerToken;
  if (!token) {
    throw new ApiError(401, "Unauthorized — no token provided");
  }

  try {
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    // try find user or admin
    const user = await User.findById(decoded._id).select("-userPassword");
    if (user) {
      req.user = user;
      return next();
    }
    const admin = await Admin.findById(decoded._id).select("-password");
    if (admin) {
      req.user = admin;
      return next();
    }
    throw new ApiError(401, "Unauthorized — user/admin not found");
  } catch (err) {
    throw new ApiError(401, "Invalid or expired token");
  }
});

export { isLoggedIn };
