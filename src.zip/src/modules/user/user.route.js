// import Router from "express";
// import { getAllUsers, deleteUser } from "./user.controller.js";

// const userRouter = Router();

// userRouter.get("/all-users", getAllUsers);
// userRouter.delete("/delete-user/:id", deleteUser);
// // 🔹 Temporary route: Delete all users where email = null
// userRouter.delete("/delete-null-users", async (req, res) => {
//   try {
//     const result = await User.deleteMany({ email: null });
//     res.json({
//       success: true,
//       deletedCount: result.deletedCount,
//       message: "Deleted all users with null emails",
//     });
//   } catch (err) {
//     res.status(500).json({
//       success: false,
//       message: err.message,
//     });
//   }
// });

// export default userRouter;
// src/modules/user/user.route.js
import express from "express";
import { upload } from "../../core/middleware/multer.js";
import { getAllUsers, createUser, updateUserAvatar, deleteUserAvatar, getUserProfile } from "./user.controller.js";

const router = express.Router();

router.get("/", getAllUsers);
router.get("/:userId", getUserProfile);
router.post("/", upload.single("avatar"), createUser);
router.patch("/avatar/:userId", upload.single("avatar"), updateUserAvatar);
router.delete("/avatar/:userId", deleteUserAvatar);

export default router;
