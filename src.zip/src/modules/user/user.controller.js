// import { ApiError } from "../../core/utils/api-error.js";
// import { ApiResponse } from "../../core/utils/api-response.js";
// import { asyncHandler } from "../../core/utils/async-handler.js";
// import User from "../../models/User.model.js";

// const getAllUsers = asyncHandler(async (req, res) => {
//   const users = await User.find();
//   if (!users) throw new ApiError(400, "User not found");
//   return res.status(200).json(new ApiResponse(200, users, "Users retrieved successfully"));
// });

// const deleteUser = asyncHandler(async (req, res) => {
//   const { id } = req.params;
//   const user = await User.findById(id);

//   if (!user) {
//     throw new ApiError(404, "User not found");
//   }

//   await user.deleteOne();
//   return res.status(200).json(new ApiResponse(200, {}, "User deleted successfully"));
// });

// export { getAllUsers, deleteUser };
// src/modules/user/user.controller.js
import User from "../../models/User.model.js";
import S3UploadHelper from "../../shared/helpers/s3Upload.js";
import { asyncHandler } from "../../core/utils/async-handler.js";
import { ApiResponse } from "../../core/utils/api-response.js";
import { ApiError } from "../../core/utils/api-error.js";


const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find().select("-userPassword");
  const usersWithAvatars = await Promise.all(
    users.map(async (user) => {
      const u = user.toObject();
      u.profileImageUrl = u.profileImage ? await S3UploadHelper.getSignedUrl(u.profileImage) : null;
      return u;
    })
  );
  res.json(new ApiResponse(200, usersWithAvatars, "Users retrieved"));
});

const createUser = asyncHandler(async (req, res) => {
  const { userName, userEmail, userPassword, userRole, phoneNumber } = req.body;
  const existing = await User.findOne({ userEmail });
  if (existing) throw new ApiError(400, "User exists");

  let avatarKey = null;
  if (req.file) {
    const uploaded = await S3UploadHelper.uploadFile(req.file, "avatars");
    avatarKey = uploaded.key;
  }

  const user = await User.create({ userName, userEmail, userPassword, userRole, phoneNumber, profileImage: avatarKey });
  const userObj = user.toObject();
  delete userObj.userPassword;
  userObj.profileImageUrl = avatarKey ? await S3UploadHelper.getSignedUrl(avatarKey) : null;

  res.status(201).json(new ApiResponse(201, userObj, "User created"));
});

const updateUserAvatar = asyncHandler(async (req, res) => {
  const { userId } = req.params;
  if (!req.file) throw new ApiError(400, "Avatar required");

  const user = await User.findById(userId);
  if (!user) throw new ApiError(404, "User not found");

  if (user.profileImage) await S3UploadHelper.deleteFile(user.profileImage);
  const uploaded = await S3UploadHelper.uploadFile(req.file, "avatars");
  user.profileImage = uploaded.key;
  await user.save();

  res.json(new ApiResponse(200, { avatarUrl: await S3UploadHelper.getSignedUrl(uploaded.key) }, "Avatar updated"));
});

const deleteUserAvatar = asyncHandler(async (req, res) => {
  const { userId } = req.params;
  const user = await User.findById(userId);
  if (!user) throw new ApiError(404, "User not found");
  if (user.profileImage) await S3UploadHelper.deleteFile(user.profileImage);

  user.profileImage = null;
  await user.save();

  res.json(new ApiResponse(200, null, "Avatar deleted"));
});

const getUserProfile = asyncHandler(async (req, res) => {
  const { userId } = req.params;
  const user = await User.findById(userId).select("-userPassword");
  if (!user) throw new ApiError(404, "User not found");

  const userObj = user.toObject();
  userObj.profileImageUrl = user.profileImage ? await S3UploadHelper.getSignedUrl(user.profileImage) : null;

  res.json(new ApiResponse(200, userObj, "Profile retrieved"));
});

export { getAllUsers, createUser, updateUserAvatar, deleteUserAvatar, getUserProfile };
