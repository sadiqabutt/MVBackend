// src/modules/admin/admin.controller.js
import Admin from "../../models/admin.models.js";
import { ApiError } from "../../core/utils/api-error.js";
import { ApiResponse } from "../../core/utils/api-response.js";
import { asyncHandler } from "../../core/utils/async-handler.js";

// ----------- GET ALL ADMINS -----------
export const getAllAdmins = asyncHandler(async (req, res) => {
  const admins = await Admin.find({});
  if (!admins || admins.length === 0) throw new ApiError(404, "No admins found");

  return res.status(200).json(new ApiResponse(200, admins, "All admins retrieved"));
});

// ----------- DELETE SINGLE ADMIN -----------
export const deleteAdmin = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const admin = await Admin.findById(id);
  if (!admin) throw new ApiError(404, "Admin not found");

  await admin.deleteOne();
  return res.status(200).json(new ApiResponse(200, {}, "Admin deleted successfully"));
});

// ----------- DELETE ALL ADMINS (Super Admin only) -----------
export const deleteAllAdmins = asyncHandler(async (req, res) => {
  if (req.user.role !== "superadmin") throw new ApiError(403, "Only superadmin can delete all admins");

  await Admin.deleteMany({});
  return res.status(200).json(new ApiResponse(200, {}, "All admins deleted successfully"));
});
