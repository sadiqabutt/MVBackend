// src/modules/admin/admin.route.js
import Router from "express";
import { getAllAdmins, deleteAdmin, deleteAllAdmins } from "./admin.controller.js";
import { isLoggedIn } from "../../core/middleware/isLoggedIn.js";

const adminRouter = Router();

adminRouter.get("/all", isLoggedIn, getAllAdmins);
adminRouter.delete("/delete/:id", isLoggedIn, deleteAdmin);
adminRouter.delete("/delete-all", isLoggedIn, deleteAllAdmins);

export default adminRouter;
