import Store from "../../models/store.model.js";
import User from "../../models/User.model.js";

// ==============================
// 🏪 Create Store (Registration)
// ==============================
export const createStore = async (req, res) => {
  try {
    const userId = req.user.id; // from auth middleware
    const {
      storeName,
      storeDescription,
      storeLogo,
      storeCoverImage,
      idCardNumber,
      idCardImage,
      storeCategoryId,
    } = req.body;

    // ✅ Check if the logged-in user already owns a store
    const existingStore = await Store.findOne({ userID: userId });
    if (existingStore) {
      return res.status(400).json({
        success: false,
        message: "You already have a store registered.",
      });
    }

    // ✅ Create new store
    const store = await Store.create({
      userID: userId,
      storeName,
      storeDescription,
      storeLogo,
      storeCoverImage,
      idCardNumber,
      idCardImage,
      storeCategoryId,
      storeStatus: "pending", // default pending until admin approves
    });

    res.status(201).json({
      success: true,
      message: "Store registered successfully. Awaiting admin approval.",
      store,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ==============================
// 🔍 Get Store by ID (Profile)
// ==============================
export const getStoreById = async (req, res) => {
  try {
    const store = await Store.findById(req.params.id).populate("userID", "userName userEmail");
    if (!store) {
      return res.status(404).json({ success: false, message: "Store not found." });
    }

    res.status(200).json({
      success: true,
      store,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ==============================
// ✏️ Update Store Profile
// ==============================
export const updateStore = async (req, res) => {
  try {
    const userId = req.user.id;
    const storeId = req.params.id;

    const store = await Store.findById(storeId);
    if (!store) {
      return res.status(404).json({ success: false, message: "Store not found." });
    }

    // ✅ Only owner can update
    if (store.userID.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized: You are not the owner of this store.",
      });
    }

    const updatedStore = await Store.findByIdAndUpdate(storeId, req.body, { new: true });

    res.status(200).json({
      success: true,
      message: "Store updated successfully.",
      store: updatedStore,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ==============================
// ✅ Admin: Verify / Reject Store
// ==============================
export const adminVerifyOrRejectStore = async (req, res) => {
  try {
    const adminId = req.user.id;
    const { action, notes } = req.body;
    const storeId = req.params.id;

    // ✅ Check admin role
    const admin = await User.findById(adminId);
    if (!admin || admin.userRole !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Only admin can perform this action.",
      });
    }

    const store = await Store.findById(storeId);
    if (!store) {
      return res.status(404).json({
        success: false,
        message: "Store not found.",
      });
    }

    if (!["live", "rejected"].includes(action)) {
      return res.status(400).json({
        success: false,
        message: "Invalid action type.",
      });
    }

    store.storeStatus = action;
    await store.save();

    res.status(200).json({
      success: true,
      message: `Store has been ${action === "live" ? "approved" : "rejected"} successfully.`,
      store,
      notes: notes || null,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
