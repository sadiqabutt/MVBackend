// import express from "express";
// import {
//   createStore,
//   getStoreById,
//   updateStore,
//   adminVerifyOrRejectStore,
// } from "../../modules/store/store.controller.js";

// import { verifyToken } from "../../core/middleware/authMiddleware.js"; // checks JWT
// import { authorizeRoles } from "../../core/middleware/roleMiddleware.js"; // checks role

// const router = express.Router();

// // ==============================
// // 🏪 Store Routes
// // ==============================

// // Create store (Only store-admin)
// router.post(
//   "/create",
//   verifyToken,
//   authorizeRoles("store-admin"),
//   createStore
// );

// // Get store by ID (Public)
// router.get("/:id", getStoreById);

// // Update store (Only owner)
// router.put(
//   "/update/:id",
//   verifyToken,
//   authorizeRoles("store-admin"),
//   updateStore
// );

// // ==============================
// // 🛡️ Admin Routes
// // ==============================

// // Admin verify/reject store
// router.put(
//   "/admin/:id/status",
//   verifyToken,
//   authorizeRoles("admin"),
//   adminVerifyOrRejectStore
// );

// export default router;
// import { isAuthenticated, authorizeRoles } from "../middleware/authMiddleware.js";

// router.post("/create", isAuthenticated, authorizeRoles("store-admin"), createStore);
import express from "express";
import {
  createStore,
  getStoreById,
  updateStore,
  adminVerifyOrRejectStore,
} from "../../modules/store/store.controller.js";

import { isAuthenticated, authorizeRoles } from "../../core/middleware/authMiddleware.js"; 

const router = express.Router();

// ==============================
// 🏪 Store Routes
// ==============================

// Create store (Only store-admin)
router.post("/create", isAuthenticated, authorizeRoles("store-admin"), createStore);

// Get store by ID (Public)
router.get("/:id", getStoreById);

// Update store (Only store-admin)
router.put("/update/:id", isAuthenticated, authorizeRoles("store-admin"), updateStore);

// ==============================
// 🛡️ Admin Routes
// ==============================

// Admin verify/reject store (Only admin)
router.put(
  "/admin/:id/status",
  isAuthenticated,
  authorizeRoles("admin"),
  adminVerifyOrRejectStore
);

export default router;
