
// // import { Router } from "express";
// // import { validate } from "../../core/middleware/validate.js";
// // import { isLoggedIn } from "../../core/middleware/isLoggedIn.js";

// // import {
// //   userRegisterSchema,
// //   userLoginSchema,
// //   userResetPasswordSchema,
// //   adminRegisterSchema,
// //   adminLoginSchema,
// //   adminForgotPasswordSchema,
// //   adminResetPasswordSchema,
// // } from "../../shared/validators/auth.validator.js";

// // import {
// //   registerUser,
// //   logInUser,
// //   logoutUser,
// //   verifyUserMail,
// //   getAccessToken,
// //   forgotPasswordMail,
// //   resetPassword,
// //   registerAdmin,
// //   loginAdmin,
// //   logoutAdmin,
// //   forgotPasswordAdmin,
// //   resetPasswordAdmin,
// //   verifyAdmin,
// // } from "./auth.controller.js";

// // const authRouter = Router();

// // /* =========================
// //    👤 USER ROUTES
// // ========================= */
// // authRouter.post("/register-user", validate(userRegisterSchema), registerUser);
// // authRouter.post("/login-user", validate(userLoginSchema), logInUser);
// // authRouter.post("/logout-user", isLoggedIn, logoutUser);
// // authRouter.get("/verify-user/:token", verifyUserMail);
// // authRouter.get("/get-access-token", getAccessToken);
// // authRouter.post("/forgot-password-user", forgotPasswordMail);
// // authRouter.post("/reset-password-user/:token", validate(userResetPasswordSchema), resetPassword);

// // /* =========================
// //    👨‍💼 ADMIN ROUTES
// // ========================= */
// // authRouter.post("/register-admin", validate(adminRegisterSchema), registerAdmin);
// // authRouter.post("/login-admin", validate(adminLoginSchema), loginAdmin);
// // authRouter.post("/logout-admin", isLoggedIn, logoutAdmin);
// // authRouter.post("/forgot-password-admin", validate(adminForgotPasswordSchema), forgotPasswordAdmin);
// // authRouter.post("/reset-password-admin/:token", validate(adminResetPasswordSchema), resetPasswordAdmin);
// // authRouter.get("/verify-admin/:token", verifyAdmin);

// // export default authRouter;
// import { Router } from "express";
// import { validate } from "../../core/middleware/validate.js";
// import { isLoggedIn } from "../../core/middleware/isLoggedIn.js";

// import {
//   userRegisterSchema,
//   userLoginSchema,
//   userResetPasswordSchema,
//   adminRegisterSchema,
//   adminLoginSchema,
//   adminForgotPasswordSchema,
//   adminResetPasswordSchema,
// } from "../../shared/validators/auth.validator.js";

// import {
//   registerUser,
//   logInUser,
//   logoutUser,
//   verifyUserMail,
//   getAccessToken,
//   forgotPasswordMail,
//   resetPassword,
//   registerAdmin,
//   loginAdmin,
//   logoutAdmin,
//   forgotPasswordAdmin,
//   resetPasswordAdmin,
//   verifyAdmin,
  
// } from "./auth.controller.js"; // ✅ upload exported from here

// const authRouter = Router();

// /* =========================
//    👤 USER ROUTES
// ========================= */

// authRouter.post("/register-user", validate(userRegisterSchema), registerUser); // ✅ add multer middleware
// authRouter.post("/login-user", validate(userLoginSchema), logInUser);
// authRouter.post("/logout-user", isLoggedIn, logoutUser);
// authRouter.get("/verify-user/:token", verifyUserMail);
// authRouter.get("/get-access-token", getAccessToken);
// authRouter.post("/forgot-password-user", forgotPasswordMail);
// authRouter.post("/reset-password-user/:token", validate(userResetPasswordSchema), resetPassword);

// /* =========================
//    👨‍💼 ADMIN ROUTES
// ========================= */
// authRouter.post("/register-admin", validate(adminRegisterSchema), registerAdmin); // ✅ same here
// authRouter.post("/login-admin", validate(adminLoginSchema), loginAdmin);
// authRouter.post("/logout-admin", isLoggedIn, logoutAdmin);
// authRouter.post("/forgot-password-admin", validate(adminForgotPasswordSchema), forgotPasswordAdmin);
// authRouter.post("/reset-password-admin/:token", validate(adminResetPasswordSchema), resetPasswordAdmin);
// authRouter.get("/verify-admin/:token", verifyAdmin);

// export default authRouter;
import Router from "express";
import { upload } from "../../core/middleware/multer.js";
import { validate } from "../../core/middleware/validate.js";
import {
  userLoginSchema,
  userRegisterSchema,
  userResetPasswordSchema,
} from "../../shared/validators/auth.validator.js";
import {
  forgotPasswordMail,
  getAccessToken,
  logInUser,
  logoutUser,
  registerUser,
  resetPassword,
  verifyUserMail,
} from "./auth.controller.js";
import { isLoggedIn } from "../../core/middleware/isLoggedIn.js";

const authRouter = Router();

/* ============================================================
   ✅ REGISTER USER (with optional profile image upload to S3)
============================================================ */
authRouter.post(
  "/register-user",
  upload.single("profileImage"), // <-- Must match the file field name in Postman
  (req, res, next) => {
    // Convert JSON-like strings to actual objects
    if (req.body && typeof req.body === "object") {
      for (const key in req.body) {
        try {
          req.body[key] = JSON.parse(req.body[key]);
        } catch {
          // leave normal text values as is
        }
      }
    }
    next();
  },
  validate(userRegisterSchema), // ⬅️ Validate AFTER parsing
  registerUser
);

/* ============================================================
   🔐 LOGIN USER
============================================================ */
authRouter.post("/login-user", validate(userLoginSchema), logInUser);

/* ============================================================
   🚪 LOGOUT USER
============================================================ */
authRouter.post("/logout-user", isLoggedIn, logoutUser);

/* ============================================================
   ✉️ VERIFY EMAIL
============================================================ */
authRouter.get("/verify/:token", verifyUserMail);

/* ============================================================
   🔁 GET ACCESS TOKEN
============================================================ */
authRouter.get("/get-access-token", getAccessToken);

/* ============================================================
   🔑 FORGOT PASSWORD MAIL
============================================================ */
authRouter.post("/forgot-password-mail", forgotPasswordMail);

/* ============================================================
   🔒 RESET PASSWORD
============================================================ */
authRouter.post(
  "/reset-password/:token",
  validate(userResetPasswordSchema),
  resetPassword
);

export default authRouter;
