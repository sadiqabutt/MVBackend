
// import crypto from "crypto";
// import { asyncHandler } from "../../core/utils/async-handler.js";
// import Admin from "../../models/admin.models.js";
// import User from "../../models/User.model.js";
// import { ApiError } from "../../core/utils/api-error.js";
// import { ApiResponse } from "../../core/utils/api-response.js";
// import { mailTransporter } from "../../shared/helpers/mail.helper.js";
// import {
//   userVerificationMailBody,
//   userForgotPasswordMailBody,
//   adminVerificationMailBody,
//   adminForgotPasswordMailBody,
// } from "../../shared/constants/mail.constant.js";
// import {
//   storeAccessToken,
//   storeLoginCookies,
// } from "../../shared/helpers/cookies.helper.js";

// // /* =========================
// //    👤 USER AUTH CONTROLLERS
// // ========================= */

// const registerUser = asyncHandler(async (req, res) => {
//   const { userName, userEmail, userPassword, userRole, phoneNumber } = req.body;

//   if (!userName || !userEmail || !userPassword) {
//     throw new ApiError(400, "userName, userEmail, and userPassword are required");
//   }

//   const file = req.file;
//   let fileKey = "";

//   if (file) {
//     const uploadedFile = await S3UploadHelper.uploadFile(file, "registerUser");
//     fileKey = uploadedFile.key;
//   }

//   const existingUser = await User.findOne({ userEmail });
//   if (existingUser) throw new ApiError(400, "User already exists");

//   const user = new User({
//     userName,
//     userEmail,
//     userPassword,
//     userRole,
//     phoneNumber,
//     profileImage: fileKey,
//   });

//   await user.save(); // ✅ pre-save hook hashes password

//   // Generate verification token
//   const { unHashedToken, hashedToken, tokenExpiry } = user.generateTemporaryToken();
//   user.userVerificationToken = hashedToken;
//   user.userVerificationTokenExpiry = tokenExpiry;
//   await user.save();

//   const verificationLink = `${process.env.BASE_URL}/api/v1/auth/verify/${unHashedToken}`;

//   await mailTransporter.sendMail({
//     from: process.env.MAIL_SENDER,
//     to: userEmail,
//     subject: "Verify your email",
//     html: userVerificationMailBody(userName, verificationLink),
//   });

//   return res.status(201).json(
//     new ApiResponse(
//       201,
//       { userName, userEmail, userRole, phoneNumber, profileImage: fileKey },
//       "User created successfully"
//     )
//   );
// });

// // ✅ Login user
// const logInUser = asyncHandler(async (req, res) => {
//   const { userEmail, userPassword } = req.body;

//   if (!userEmail || !userPassword) throw new ApiError(400, "userEmail and userPassword are required");

//   const user = await User.findOne({ userEmail });
//   if (!user) throw new ApiError(400, "User not found");

//   const isPasswordCorrect = await user.isPasswordCorrect(userPassword);
//   if (!isPasswordCorrect) throw new ApiError(400, "Invalid password");

//   if (!user.userIsVerified) throw new ApiError(400, "User not verified");

//   const accessToken = user.generateAccessToken();
//   const refreshToken = user.generateRefreshToken();

//   user.userRefreshToken = refreshToken;
//   await user.save();

//   storeLoginCookies(res, accessToken, refreshToken);

//   return res.status(200).json(
//     new ApiResponse(
//       200,
//       {
//         user: { userName: user.userName, userEmail, userRole: user.userRole, phoneNumber: user.phoneNumber },
//         tokens: { accessToken, refreshToken },
//       },
//       "User logged in successfully"
//     )
//   );
// });

// // ✅ Verify user email
// const verifyUserMail = asyncHandler(async (req, res) => {
//   const { token } = req.params;
//   if (!token) throw new ApiError(400, "Token not found");

//   const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

//   const user = await User.findOne({
//     userVerificationToken: hashedToken,
//     userVerificationTokenExpiry: { $gt: Date.now() },
//   });

//   if (!user) throw new ApiError(400, "Invalid or expired verification token");

//   user.userIsVerified = true;
//   user.userVerificationToken = null;
//   user.userVerificationTokenExpiry = null;
//   await user.save();

//   return res.status(200).json(new ApiResponse(200, {}, "User verified successfully"));
// });




// // // ✅ Logout user
// // const logoutUser = asyncHandler(async (req, res) => {
// //   const userId = req.user?._id;
// //   if (!userId) throw new ApiError(401, "User not authenticated");

// //   const user = await User.findById(userId);
// //   if (!user) throw new ApiError(404, "User not found");

// //   user.userRefreshToken = null;
// //   await user.save();

// //   res.clearCookie("accessToken");
// //   res.clearCookie("refreshToken");

// //   return res.status(200).json(new ApiResponse(200, {}, "User logged out successfully"));
// // });



// // // ✅ Get new access token from refresh token
// // const getAccessToken = asyncHandler(async (req, res) => {
// //   const { refreshToken } = req.cookies;
// //   if (!refreshToken) throw new ApiError(400, "Refresh token not found");

// //   const user = await User.findOne({ userRefreshToken: refreshToken });
// //   if (!user) throw new ApiError(400, "Invalid refresh token");

// //   const accessToken = user.generateAccessToken();
// //   storeAccessToken(res, accessToken);

// //   return res.status(200).json(new ApiResponse(200, { accessToken }, "Access token generated"));
// // });

// // // ✅ Forgot password email
// // const forgotPasswordMail = asyncHandler(async (req, res) => {
// //   const { userEmail } = req.body;
// //   const user = await User.findOne({ userEmail });
// //   if (!user) throw new ApiError(400, "User not found");

// //   const { unHashedToken, hashedToken, tokenExpiry } = user.generateTemporaryToken();
// //   user.userPasswordResetToken = hashedToken;
// //   user.userPasswordExpirationDate = tokenExpiry;
// //   await user.save();

// //   const resetLink = `${process.env.BASE_URL}/api/v1/auth/reset-password/${unHashedToken}`;

// //   await mailTransporter.sendMail({
// //     from: process.env.MAIL_SENDER,
// //     to: userEmail,
// //     subject: "Reset Password",
// //     html: userForgotPasswordMailBody(user.userName, resetLink),
// //   });

// //   return res.status(200).json(new ApiResponse(200, { resetLink }, "Password reset email sent"));
// // });

// // // ✅ Reset password
// // const resetPassword = asyncHandler(async (req, res) => {
// //   const { token } = req.params;
// //   const { userPassword } = req.body;

// //   const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

// //   const user = await User.findOne({
// //     userPasswordResetToken: hashedToken,
// //     userPasswordExpirationDate: { $gt: Date.now() },
// //   });
// // v
// //   if (!user) throw new ApiError(400, "Invalid or expired password reset token");

// //   user.userPassword = userPassword;
// //   user.userPasswordResetToken = null;
// //   user.userPasswordExpirationDate = null;
// //   await user.save();

// //   return res.status(200).json(new ApiResponse(200, {}, "Password reset successfully"));
// // });

// // export {
// //   registerUser,
// //   logInUser,
// //   logoutUser,
// //   verifyUserMail,
// //   getAccessToken,
// //   forgotPasswordMail,
// //   resetPassword,
// // };

// // /* =========================
// //    👨‍💼 ADMIN AUTH CONTROLLERS
// // ========================= */

// // // Register Admin
// // const registerAdmin = asyncHandler(async (req, res) => {
// //   const { name, email, password, role, contact_no } = req.body;
// //   const existing = await Admin.findOne({ email });
// //   if (existing) throw new ApiError(400, "Admin already exists");

// //   const admin = await Admin.create({ name, email, password, role, contact_no });
// //   const token = admin.generateTemporaryToken(); // raw token
// //   await admin.save();

// //   const link = `${process.env.BASE_URL}/api/v1/auth/verify-admin/${token}`;

// //   await mailTransporter.sendMail({
// //     from: process.env.MAILTRAP_SENDEREMAIL,
// //     to: email,
// //     subject: "Verify your admin account",
// //     html: adminVerificationMailBody(name, link),
// //   });

// //   const response = { name: admin.name, email: admin.email, role: admin.role, contact_no: admin.contact_no };
// //   return res.status(201).json(new ApiResponse(201, response, "Admin registered successfully, please verify via email"));
// // });

// // const verifyAdmin = asyncHandler(async (req, res) => {
// //   const { token } = req.params;
// //   if (!token) throw new ApiError(400, "Token not found");

// //   const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

// //   const admin = await Admin.findOne({
// //     verificationToken: hashedToken,
// //     verificationTokenExpiry: { $gt: Date.now() }
// //   });

// //   if (!admin) throw new ApiError(400, "Invalid or expired verification token");

// //   admin.isVerified = true;
// //   admin.verificationToken = null;
// //   admin.verificationTokenExpiry = null;
// //   await admin.save();

// //   return res.status(200).json(new ApiResponse(200, {}, "Admin verified successfully"));
// // });

// // // Login Admin
// // const loginAdmin = asyncHandler(async (req, res) => {
// //   const { email, password } = req.body;
// //   const admin = await Admin.findOne({ email });
// //   if (!admin) throw new ApiError(404, "Admin not found");
// //   if (!admin.isVerified) throw new ApiError(403, "Admin not verified yet");

// //   const isPasswordCorrect = await admin.isPasswordCorrect(password);
// //   if (!isPasswordCorrect) throw new ApiError(400, "Invalid password");

// //   const accessToken = await admin.generateAccessToken();
// //   const refreshToken = await admin.generateRefreshToken();

// //   storeLoginCookies(res, accessToken, refreshToken);
// //   admin.adminRefreshToken = refreshToken;
// //   await admin.save();

// //   const response = {
// //     admin: { name: admin.name, email: admin.email, role: admin.role, contact_no: admin.contact_no },
// //     tokens: { accessToken, refreshToken },
// //   };
// //   return res.status(200).json(new ApiResponse(200, response, "Admin login successful"));
// // });

// // // Logout Admin
// // const logoutAdmin = asyncHandler(async (req, res) => {
// //   const adminId = req.user?._id;
// //   if (!adminId) throw new ApiError(401, "Admin not authenticated");

// //   const admin = await Admin.findById(adminId);
// //   if (!admin) throw new ApiError(404, "Admin not found");

// //   admin.adminRefreshToken = null;
// //   await admin.save();

// //   res.clearCookie("accessToken", { httpOnly: false, secure: process.env.NODE_ENV === "production", sameSite: "strict" });
// //   res.clearCookie("refreshToken", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict" });

// //   return res.status(200).json(new ApiResponse(200, {}, "Admin logged out successfully"));
// // });

// // // Forgot Password Admin
// // const forgotPasswordAdmin = asyncHandler(async (req, res) => {
// //   const { email } = req.body;
// //   const admin = await Admin.findOne({ email });
// //   if (!admin) throw new ApiError(404, "Admin not found");

// //   const token = admin.generateTemporaryToken(); // raw token
// //   await admin.save();

// //   const resetLink = `${process.env.BASE_URL}/api/v1/auth/reset-password-admin/${token}`;

// //   await mailTransporter.sendMail({
// //     from: process.env.MAILTRAP_SENDEREMAIL,
// //     to: email,
// //     subject: "Reset your admin password",
// //     html: adminForgotPasswordMailBody(admin.name, resetLink),
// //   });

// //   return res.status(200).json(new ApiResponse(200, { resetLink }, "Admin reset link sent successfully"));
// // });

// // // Reset Password Admin
// // const resetPasswordAdmin = asyncHandler(async (req, res) => {
// //   const { token } = req.params;
// //   const { password } = req.body;

// //   const hashedToken = crypto.createHash("sha256").update(token).digest("hex");
// //   const admin = await Admin.findOne({ resetPasswordToken: hashedToken, resetPasswordExpire: { $gt: Date.now() } });
// //   if (!admin) throw new ApiError(400, "Invalid or expired token");

// //   admin.password = password;
// //   admin.resetPasswordToken = null;
// //   admin.resetPasswordExpire = null;
// //   await admin.save();

// //   return res.status(200).json(new ApiResponse(200, {}, "Password reset successfully"));
// // });

// // export {
// //   registerAdmin,
// //   verifyAdmin,
// //   loginAdmin,
// //   logoutAdmin,
// //   forgotPasswordAdmin,
// //   resetPasswordAdmin,
// // };

import { asyncHandler } from "../../core/utils/async-handler.js";
import User from "../../models/User.model.js";
import { ApiError } from "../../core/utils/api-error.js";
import { ApiResponse } from "../../core/utils/api-response.js";
import { userForgotPasswordMailBody, userVerificationMailBody } from "../../shared/constants/mail.constant.js";
import { mailTransporter } from "../../shared/helpers/mail.helper.js";
import { storeAccessToken, storeLoginCookies } from "../../shared/helpers/cookies.helper.js";
import crypto from "crypto";
import S3UploadHelper from "../../shared/helpers/s3Upload.js"; // ✅ Added import for AWS logic

const registerUser = asyncHandler(async (req, res) => {
    const { userName, userEmail, userPassword, userRole, phoneNumber, userAddress } = req.body;
    const existingUser = await User.findOne({ userEmail });
    if (existingUser) {
        throw new ApiError(400, "User already exists");
    }

    // ✅ Handle profile image upload (if provided)
    let profileImageKey = null;
    if (req.file) {
        try {
            const uploadResult = await S3UploadHelper.uploadFile(req.file, "user-profiles");
            profileImageKey = uploadResult.key; // Store the S3 key for later retrieval
        } catch (error) {
            console.error("S3 Upload Error:", error);
            throw new ApiError(500, "Profile image upload failed");
        }
    }

    const user = await User.create({
        userName,
        userEmail,
        userPassword,
        userRole,
        phoneNumber,
        userAddress,
        ...(profileImageKey && { profileImage: profileImageKey }) // ✅ store S3 key if available
    });

    if (!user) {
        throw new ApiError(400, "User not Created");
    }

    const { unHashedToken, hashedToken, tokenExpiry } = user.generateTemporaryToken();

    user.userVerificationToken = hashedToken;
    user.userVerificationTokenExpiry = tokenExpiry;
    await user.save();

    console.log("User created:", user);

    const userVerificationEmailLink = `${process.env.BASE_URL}/api/v1/auth/verify/${unHashedToken}`;

    await mailTransporter.sendMail({
        from: process.env.MAILTRAP_SENDEREMAIL,
        to: userEmail,
        subject: "Verify your email",
        html: userVerificationMailBody(userName, userVerificationEmailLink),
    });

    const response = {
        userName: user.userName,
        userEmail: user.userEmail,
        userRole: user.userRole,
        phoneNumber: user.phoneNumber,
        userAddress: user.userAddress,
        ...(profileImageKey && { profileImage: profileImageKey })
    };

    return res
        .status(201)
        .json(
            new ApiResponse(
                201,
                response,
                "User created successfully"
            )
        );
});

const logInUser = asyncHandler(async (req, res) => {
    const { userEmail, userPassword } = req.body;
    const user = await User.findOne({ userEmail });
    if (!user) {
        throw new ApiError(400, "User not found");
    }

    const isPasswordCorrect = await user.isPasswordCorrect(userPassword);
    if (!isPasswordCorrect) {
        throw new ApiError(400, "Invalid password");
    }

    if (!user.userIsVerified) {
        throw new ApiError(400, "User not verified");
    }

    const accessToken = await user.generateAccessToken();
    const refreshToken = await user.generateRefreshToken();

    storeLoginCookies(res, accessToken, refreshToken, "user");

    user.userRefreshToken = refreshToken;
    await user.save();

    const response = {
        user: {
            userName: user.userName,
            userEmail: user.userEmail,
            userRole: user.userRole,
            phoneNumber: user.phoneNumber,
            profileImage: user.profileImage || null
        },
        tokens: {
            accessToken,
            refreshToken
        }
    };

    return res
        .status(201)
        .json(
            new ApiResponse(
                201,
                response,
                "User logged in successfully"
            )
        );
});

const logoutUser = asyncHandler(async (req, res) => {
    const userId = req.user?._id;

    if (!userId) {
        throw new ApiError(401, "User not authenticated");
    }

    const user = await User.findById(userId);
    if (!user) {
        throw new ApiError(404, "User not found");
    }

    user.userRefreshToken = null;
    await user.save();

    res.clearCookie("accessToken", {
        httpOnly: false,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
    });

    res.clearCookie("refreshToken", {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
    });

    return res
        .status(200)
        .json(new ApiResponse(200, {}, "User logged out successfully"));
});

const verifyUserMail = asyncHandler(async (req, res) => {
    const { token } = req.params;
    if (!token) {
        throw new ApiError(400, "Token not found");
    }
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");
    const user = await User.findOne({
        userVerificationToken: hashedToken,
        userVerificationTokenExpiry: { $gt: Date.now() },
    });
    if (!user) {
        throw new ApiError(400, "Invalid or expired verification token");
    }

    user.userIsVerified = true;
    user.userVerificationToken = null;
    user.userVerificationTokenExpiry = null;
    await user.save();

    return res
        .status(200)
        .json(new ApiResponse(200, {}, "User verified successfully"));
});

const getAccessToken = asyncHandler(async (req, res) => {
    const { userRefreshToken } = req.cookies;
    if (!userRefreshToken) throw new ApiError(400, "Refresh token not found");

    const user = await User.findOne({ userRefreshToken });
    if (!user) throw new ApiError(400, "Invalid refresh token");

    const accessToken = await user.generateAccessToken();

    await storeAccessToken(res, accessToken, "user");

    return res
        .status(201)
        .json(
            new ApiResponse(
                201,
                { accessToken },
                "User access token generated successfully"
            )
        );
});

const forgotPasswordMail = asyncHandler(async (req, res) => {
    const { userEmail } = req.body;

    const user = await User.findOne({ userEmail });
    if (!user) {
        throw new ApiError(400, "User not found");
    }

    const { unHashedToken, hashedToken, tokenExpiry } = user.generateTemporaryToken();

    user.userPasswordResetToken = hashedToken;
    user.userPasswordExpirationDate = tokenExpiry;
    await user.save();

    const userPasswordResetLink = `${process.env.BASE_URL}/api/v1/auth/reset-password/${unHashedToken}`;

    await mailTransporter.sendMail({
        from: process.env.MAILTRAP_SENDEREMAIL,
        to: userEmail,
        subject: "Reset your password",
        html: userForgotPasswordMailBody(user.userName, userPasswordResetLink),
    });

    return res
        .status(201)
        .json(
            new ApiResponse(
                201,
                { userPasswordResetLink },
                "Password reset link sent successfully"
            )
        );
});

const resetPassword = asyncHandler(async (req, res) => {
    const { token } = req.params;
    const { userPassword } = req.body;

    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
        userPasswordResetToken: hashedToken,
        userPasswordExpirationDate: { $gt: Date.now() },
    });

    if (!user) {
        throw new ApiError(400, "Invalid or expired password reset token");
    }

    user.userPassword = userPassword;
    user.userPasswordResetToken = null;
    user.userPasswordExpirationDate = null;
    await user.save();

    return res
        .status(201)
        .json(new ApiResponse(201, {}, "Password reset successfully"));
});

export { registerUser, logInUser, logoutUser, verifyUserMail, getAccessToken, forgotPasswordMail, resetPassword };