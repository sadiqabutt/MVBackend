import express from "express";
import { createCategory } from "../../modules/category/category.controller.js";

const router = express.Router();

// Create category
router.post("/create", createCategory);

export default router;
