import Category from "../../models/category.model.js";
import { asyncHandler } from "../../core/utils/async-handler.js";
import { ApiResponse } from "../../core/utils/api-response.js";

export const createCategory = asyncHandler(async (req, res) => {
    const { name, description } = req.body;
    const category = await Category.create({ name, description });
    return res.status(201).json(new ApiResponse(201, category, "Category created successfully"));
});
